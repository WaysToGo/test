
app = angular.module('todoApp', [])
            
app.controller('tasksCtrl', ['$scope', '$http', function($scope, $http) {

    $scope.data = {
        task: ''
    }

    var getAllTasks = function () {
        $http({
            url: 'http://localhost:8080/demo/api/tasks/'
        })
        .then(function (resp) {
            $scope.tasks = resp.data
        })
    }

    $scope.addTask = function (name) {
        $http({
            url: 'http://localhost:8080/demo/api/tasks/',
            method: 'POST',
            data: {
                name: name
            }
        }).then(function (resp) {
            $scope.data.task = ''
            getAllTasks()
        })
    }

    $scope.deleteTask = function (id) {
        
        $http({
            url: 'http://localhost:8080/demo/api/tasks/' + id,
            method: 'DELETE'
        }).then(function (resp) {
            
            getAllTasks()
        })
    }

    getAllTasks()
}])