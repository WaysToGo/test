var assert = require('assert'); 
var convertBinary=require('../app');

describe('should return string', function() {
    
    it('test1', function(){
        assert.equal(convertBinary(20),'010100');
      });
      it('test2', function(){
        assert.equal(convertBinary(99), '01100011');
      });
      it('test3', function(){
        assert.equal(convertBinary(12), '01100');
      });
      it('test4', function(){
        assert.equal(convertBinary(15), '01111');
      });
      it('test5', function(){
        assert.equal(convertBinary(16), '010000');
      });
      it('test6', function(){
        assert.equal(convertBinary(1),'01');
      });
      it('test7', function(){
        assert.equal(convertBinary(3), '011');
      });
      it('test8', function(){
        assert.equal(convertBinary(7), '0111');
      });
      it('test9', function(){
        assert.equal(convertBinary(56), '0111000');
      });
  });

