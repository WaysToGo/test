var assert = require('assert'); 
var convertBinary=require('../app');

describe('should return string', function() {
    
    it('test1', function(){
        assert.equal(convertBinary(20),'10100');
      });
      it('test2', function(){
        assert.equal(convertBinary(99), '1100011');
      });
      it('test3', function(){
        assert.equal(convertBinary(12), '1100');
      });
      it('test4', function(){
        assert.equal(convertBinary(15), '1111');
      });
      it('test5', function(){
        assert.equal(convertBinary(16), '10000');
      });
      it('test6', function(){
        assert.equal(convertBinary(1),'1');
      });
      it('test7', function(){
        assert.equal(convertBinary(3), '11');
      });
      it('test8', function(){
        assert.equal(convertBinary(7), '111');
      });
      it('test9', function(){
        assert.equal(convertBinary(56), '111000');
      });
  });

