

module.exports=function convertBinary(n) {
    return (n = n.toString(2))[0] == 0 ? n : `0${n}`
}