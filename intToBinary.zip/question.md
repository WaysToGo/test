convert int to bimary
 
 examples 

convertBinary(1)=>'01'
convertBinary(3)=>'011'
convertBinary(6)=>'0110'
convertBinary(7)=>'0110'
