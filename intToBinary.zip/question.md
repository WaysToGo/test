convert int to bimary
 
 examples 
 
convertBinary(3)=>'11'
convertBinary(6)=>'110'
convertBinary(7)=>'110'
