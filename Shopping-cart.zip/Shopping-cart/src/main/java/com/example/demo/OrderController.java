package com.example.demo;

import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/order")
public class OrderController {
	
	@Autowired
	ProductModel productModel;
		
//	  @GET
//	    @Produces("application/json")
//	    public List<AmbulanceModel> getAlldetails() {		
//	        return ambulancerepo.findAll();
//	    }
//	  
//	  @POST
//	  @Consumes("application/json")
//	  @Produces("application/json")
//	     public Response saveAlldetails(AmbulanceModel details){		 
//		  ambulancerepo.save(details);
//		  return Response.created(URI.create("/" + details.getId())).build();
//		  
//	  }
//	  
//	  
//	  @GET
//	  @Path("/{id}")
//	    @Produces("application/json")
//	    public AmbulanceModel getDetails(@PathParam("id") int id) {	 	
//	        return ambulancerepo.findOne(id);
//	        }
//	  
//	  
//	  @PUT
//	  @Path("/{id}")
//	  @Consumes("application/json")
//	  @Produces("application/json")
//	  public Response saveDetails(@PathParam("id") int id,AmbulanceModel Details){
//		  
//			Details.setId(id);
//			 ambulancerepo.save(Details);
// 		  return Response.noContent().build();
//		  
//	  }
//	  
//	  
//	  @DELETE
//	  @Path("/{id}")
//	  public Response deletedetails(@PathParam("id") int id){		  
//		  ambulancerepo.delete(id);
//		  
//		 return Response.ok().build();
//		  
//	  }
//	  
//
//	  
	  


}
