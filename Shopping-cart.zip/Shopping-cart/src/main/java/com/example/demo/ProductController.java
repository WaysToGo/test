package com.example.demo;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/product")
public class ProductController {
	
	@Autowired
	ProductRepo productRepo;
		
	  @GET
	    @Produces("application/json")
	    public List<ProductModel> getAlldetails() {		
	        return productRepo.findAll();
	    }
	  
	
	  
	  


}
