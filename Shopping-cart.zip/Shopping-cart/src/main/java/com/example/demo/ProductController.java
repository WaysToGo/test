package com.example.demo;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/products")
public class ProductController {
	
	@Autowired
	ProductRepo productRepo;
		
	  @GET
	    @Produces("application/json")
	    public List<ProductModel> getAlldetails() {		
	        return productRepo.findAll();
	    }
	  
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	     public Response saveAlldetails(ProductModel  details){		 
		  productRepo.save(details);
		  return Response.created(URI.create("/" + details.getProduct_id())).build();
		  
	  }

}
