package com.example.demo;



import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;
import org.springframework.stereotype.Component;

@Component
@ApplicationPath("/api")
public class JerseyApplication extends ResourceConfig {
    public JerseyApplication() {
      
        
        register(CORSResponseFilter.class);
        register(ProductController.class);
        register(CategoryController.class);
        register(CustomerController.class);
        register(OrderController.class);
        register(ProductCartController.class);
        
    
    }
}