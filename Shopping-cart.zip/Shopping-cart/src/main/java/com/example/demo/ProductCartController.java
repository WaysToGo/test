package com.example.demo;

import java.net.URI;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/productcart")
public class ProductCartController {
	
	@Autowired
	ProductCartRepo productCartRepo;
		
	  @GET
	    @Produces("application/json")
	    public List<ProductCartModel> getAlldetails() {		
	        return productCartRepo.findAll();
	    }
	  
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	     public Response saveAlldetails(ProductCartModel details){		 
		  productCartRepo.save(details);
		  return Response.created(URI.create("/" + details.getCart_id())).build();
		  
	  }
	  
	  
	  @GET
	  @Path("/{id}")
	    @Produces("application/json")
	    public ProductCartModel getDetails(@PathParam("id") Long id) {	 	
	        return productCartRepo.findOne(id);
	        }
	  
	  
	  @PUT
	  @Path("/{id}")
	  @Consumes("application/json")
	  @Produces("application/json")
	  public Response saveDetails(@PathParam("id") Long id,ProductCartModel Details){
		  
			Details.setCart_id(id);
			 productCartRepo.save(Details);
 		  return Response.noContent().build();
		  
	  }
	  
	  
	  @DELETE
	  @Path("/{id}")
	  public Response deletedetails(@PathParam("id") Long id){		  
		  productCartRepo.delete(id);
		  
		 return Response.ok().build();
		  
	  }
	  

	  
	  


}
