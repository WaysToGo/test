export interface IProduct {
     product_id:number; 
	 name:string;
	 photo:string;
	 category_id:number;
	 manufacturer:string;
	 model:string;
	 price:number;
	 discount:number;
	 stock:number;
}

