package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CheckOutWebTest {
	public DesiredCapabilities caps;
	public WebDriver driver;
	public String url="http://localhost:8000/Shopping-cart-app/";
	@Before
	public void init() {
		caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability("takesScreenshot", true);
    final ChromeOptions chromeOptions = new ChromeOptions();
    // chromeOptions.setBinary("/opt/chromedriver");
    chromeOptions.addArguments("--headless");
    chromeOptions.addArguments("--disable-gpu");
    chromeOptions.addArguments("--no-sandbox");
    caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
    System.setProperty("webdriver.chrome.driver", "/opt/chromedriver");
    
//    System.setProperty("webdriver.chrome.driver", "D:\\projects\\impfile\\chromedriver.exe");
    driver = new ChromeDriver(caps);


		
	}

	 
	 



	  
	  @Test 
	  public void testOrder2() throws InterruptedException {
		 
		  try { 
			  driver.get(url);
		  driver.findElement(By.id("count")).click();
		  Thread.sleep(2000);
		  driver.findElement(By.id("checkout")).click();
		  Thread.sleep(2000);
		   driver.findElement(By.id("submit")).click();
		   Thread.sleep(2000);
		 
		   assertEquals("Order placed succesfully",driver.findElement(By.id("success-message")).getAttribute("innerText"));
		 }
		 finally {
		    driver.close();
		 }
	  }
	  


}

