package com.example.demo;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProductWebTest {
	public DesiredCapabilities caps;
	public WebDriver driver;
	public String url="http://localhost:8000/";
	@Before
	public void init() {
		caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability("takesScreenshot", true);
    final ChromeOptions chromeOptions = new ChromeOptions();
    // chromeOptions.setBinary("/opt/chromedriver");
    chromeOptions.addArguments("--headless");
    chromeOptions.addArguments("--disable-gpu");
    chromeOptions.addArguments("--no-sandbox");
    caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
//    System.setProperty("webdriver.chrome.driver", "/opt/chromedriver");
    
    System.setProperty("webdriver.chrome.driver", "D:\\projects\\impfile\\chromedriver.exe");
    driver = new ChromeDriver(caps);


		
	}



	  
	  @Test 
	  public void testOrder1() throws InterruptedException {
		 try {
		  driver.get(url);
		 String beforecount=driver.findElement(By.id("count")).getAttribute("innerText");		   
		  int value=Integer.parseInt(beforecount);
		  Thread.sleep(2000);
		   driver.findElements(By.className("addtocart")).get(0).click();
		   Thread.sleep(2000);
		   String aftercount=driver.findElement(By.id("count")).getAttribute("innerText");
		   int aftervalue=Integer.parseInt(aftercount);
		   Thread.sleep(2000);
		   assertEquals(aftervalue,value+1);
		 }
		 finally {
		    driver.close();
		 }
	  }
	  


}

