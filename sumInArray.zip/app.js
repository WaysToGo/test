module.exports=function sumofnumbers(){
    var length=arguments.length;
    var sum=0;
    var i=0;
    for(i=0;i<length;i++){
          sum=sum+arguments[i];  
   }
   return sum;
 };
