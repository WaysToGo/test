var assert = require('assert'); 
var sumofnumbers=require('../app')

  describe('should return number', function() {
    
    it('test1', function(){
        assert.equal(sumofnumbers(1,3),4 );
      });
      it('test2', function(){
        assert.equal(sumofnumbers(1,1,1,1,1,1), 6);
      });
      it('test3', function(){
        assert.equal(sumofnumbers(2,2,2,2,2,2,2), 14);
      });
      it('test4', function(){
        assert.equal(sumofnumbers(3,3,3,3,3,3,3,3), 24);
      });
      it('test5', function(){
        assert.equal(sumofnumbers(1,2,3,4,5), 15);
      });
      it('test6', function(){
        assert.equal(sumofnumbers(1,2,3,4), 10);
      });
      it('test7', function(){
        assert.equal(sumofnumbers(1), 1);
      });
      it('test8', function(){
        assert.equal(sumofnumbers(1,2,3), 6);
      });
      it('test9', function(){
        assert.equal(sumofnumbers(1,2), 3);
      });
  });


