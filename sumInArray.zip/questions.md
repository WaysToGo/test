return sum of arguments given as input

sumofnumbers(1)=>1
sumofnumbers(2,2)=>4
sumofnumbers(1,2,3,4,5)=>15

