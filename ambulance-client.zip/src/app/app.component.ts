import { Component } from '@angular/core';

import {MatTableDataSource} from '@angular/material';
import { Http,Response,RequestOptions } from '@angular/http';
import {Details} from './details.compoment';
import { OnInit } from '@angular/core/src/metadata/lifecycle_hooks';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  ngOnInit(): void {
    this.getAllDetails();
  }
  details: any = [];
  displayedColumns = ['id', 'distance', 'provider', 'mobile', 'buttons'];
  dataSource = '';

  check = false;
  length = 1000000;
  mobile = 1000000;
  data = {
    id: '',
    distance: '',
    provider: '',
    mobile: ''

  }


  constructor(private http: Http) {
  }

  getAllDetails = function () {
    this.http.get('http://localhost:8000/api/ambulance/').subscribe((res: Response) => {
      let body = res.json();
      this.details = body;
      this.dataSource = new MatTableDataSource < Details > (this.details);
    })
  };



  addDetails(data) {
    let headers = new Headers({
      'Content-Type': 'application/json'
    });

    this.http.post('http://localhost:8000/api/ambulance/', {
      "id": data.id,
      "distance": data.distance,
      "provider": data.provider,
      "mobile": data.mobile
    }).subscribe((res: Response) => {
      this.data.id = '';
      this.data.distance = '';
      this.data.provider = '';
      this.data.mobile = '';
      this.getAllDetails();
    })
  };

  deleteDetails(name) {
    this.http.delete('http://localhost:8000/api/ambulance/' + name).subscribe((res: Response) => {
      this.getAllDetails();

    })
  }

  nearByAmbulance() {

    this.details.filter(a => {
      if (a.distance < this.length) {
        this.length = a.distance;
        this.mobile = a.mobile;
        return true;
      }
    })
    this.check = true;
    this.length = 1000000;
  }



}
