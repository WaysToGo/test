

export interface Details {
    id: number;
    distance: number;
    provider: string;
    mobile:string
  }
 