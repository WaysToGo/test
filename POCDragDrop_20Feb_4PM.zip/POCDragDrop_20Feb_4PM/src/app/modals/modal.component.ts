import { Component, OnInit, ViewChild, DoCheck, EventEmitter, Output, Input } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators, NgForm, FormBuilder } from '@angular/forms';

@Component({
    selector: 'app-modal',
    templateUrl: './modal.component.html',
    styleUrls: ['./modal.component.scss']
})

export class ModalComponent implements OnInit, DoCheck {
    @Input() id: number;
    closeResult: string;

    myform: FormGroup;
    Id: FormControl;
    comment: FormControl;

   


    @Output() eventEmit: EventEmitter<any> = new EventEmitter<any>();
    //@ViewChild('content') templateContent : NgbModal;


    constructor(private modalService: NgbModal) {
        
       
        console.log(this.id);

    }
    ngDoCheck() {

    }
    ngOnInit() {
        this.createFormControls();
        this.createForm();
        this.BindRecord();
        console.log(this.id);
    }

    createFormControls(): void {
        this.comment = new FormControl('', Validators.required);
        this.Id = new FormControl('');
    }
    createForm(): void {
        this.myform = new FormGroup({
            commentGroup: new FormGroup({
                comment: this.comment,
                Id: this.Id
            }),
        });
    }
    open(content) {
        this.eventEmit.emit(content);
        this.modalService.open(content).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }

    ClearComment(): void {
         
      
    }

    Save(myForm: NgForm) {
        
    }

    BindRecord() {
      
    }

    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }
}