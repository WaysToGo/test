import { Injectable } from '@angular/core';
import { Comment } from '../model/Comment';
import { Items } from '../model/Items';


@Injectable()
export class StorageService {
  constructor() { }
  set(a: string, b: any): void {
    $.jStorage.set(a, b);
  }
  get(a: string): Items[] {
    return $.jStorage.get(a);
  }
  deleteKey(a: any): void {
    $.jStorage.deleteKey(a);
  }
}
