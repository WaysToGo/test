import { Injectable } from '@angular/core';
import { Comment } from '../model/Comment';
import { StorageService } from './storage.service';
 
@Injectable()
export class CommentService {
      
  constructor(public storageService: StorageService) {
   
  }
  getCommentList(): Comment[] {
      let oList: Comment[] = new Array<Comment>();
     // oList = this.storageService.get("CL") as Comment[];
      return oList == null ? null : oList;
  }
  getCommentListById(Id: number): Comment[] {
     /* let oList: Comment[] = new Array<Comment>();
      oList = this.storageService.get("CL") as Comment[];
      return oList == null ? null : oList.filter(c => c.Id == Id);*/
      return null;
  }
  AddComment(commentList: Comment[]): void {
      this.storageService.set("CL", commentList);
     
  }
}