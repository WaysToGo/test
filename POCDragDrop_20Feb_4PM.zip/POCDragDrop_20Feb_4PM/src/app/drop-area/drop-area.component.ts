import { Component, EventEmitter, Input, Output } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DefaultModal } from '../models/default/default-modal.component';
import { Items } from '../model/Items';
import { tick } from '@angular/core/testing';

@Component({
  selector: 'app-drop-area',
  template: `
  <div class="panel panel-default">
	<div class="panel-heading">
			<h3 class="panel-title">Editor</h3>
	</div>
	<div class="panel-body" style=" -ms-layout-grid: mode;">
    <div dropDirective (dropEvent)="addDropItem($event)"  class="droppable"  [dropHighlight]="'highlight'" (dragleaveEvent)="dragLeave($event)">
    <app-generic-box ngDraggable *ngFor="let item of itemsDropped" [dragDirective]='item' [genericBox]='item' (dblclick)='openPopUp(item)' class="dropItem" (releaseDrop)="releaseDrop($event)"></app-generic-box>
    </div>
    </div>
  </div>
  `,
  styleUrls: ['./drop-area.component.css']
})
export class DropAreaComponent {

  private itemsDropped: Array<Items> = [];
  constructor(private modalService: NgbModal) { }

  private addDropItem(event) {
    this.itemsDropped.push(event);
  }

  private dragLeave(event) {
    let index = this.itemsDropped.indexOf(event);
    if (index >= 0) {
      this.itemsDropped.splice(index, 1);
    }
  }

  private openPopUp(text) {
    const activeModalRef = this.modalService.open(DefaultModal, { size: 'lg' });
    activeModalRef.componentInstance.title = text.content;
    activeModalRef.componentInstance.modifiedTitle.subscribe((emmitedValue) => {
    text.content = emmitedValue;
    });
  }

  private releaseDrop(event) {
    let index = this.itemsDropped.indexOf(event);
    if (index >= 0) {
      this.itemsDropped.splice(index, 1);
    }
  }

}
