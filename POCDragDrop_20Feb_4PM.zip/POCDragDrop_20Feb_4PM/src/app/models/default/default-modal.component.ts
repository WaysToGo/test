
import { Component, OnInit, ViewChild, DoCheck, EventEmitter, Output, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, NgForm, FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { Comment } from '../../model/Comment';
import { Items } from '../../model/Items';

@Component({
    selector: 'add-service-modal',
    templateUrl: './default-modal.component.html'
})

export class DefaultModal implements OnInit {
    headerText: string;
    id: number;

    modalHeader: string;
    modalContent: string = ``;

    constructor(private activeModal: NgbActiveModal) {

        this.comment = new Comment();
        this.items = new Array<Items>();
    }

    closeModal() {
        this.activeModal.close();
    }

    @Input() title: string;
    @Input() Id: number;
    @Output() modifiedTitle = new EventEmitter<string>();

    private items: Items[];
    myform: FormGroup;
    commentFormControl: FormControl;
    comment: Comment;
    commentList: Array<Comment>;

    ngOnInit() {
        this.createFormControls();
        this.createForm();
        console.log(this.headerText);
    }
    createFormControls(): void {
        this.commentFormControl = new FormControl('', Validators.required);
    }
    createForm(): void {
        this.myform = new FormGroup({
            commentGroup: new FormGroup({
                commentFormControl: this.commentFormControl
            }),
        });
    }

    Save(myForm: NgForm) {
        this.comment.Comment = myForm.value.commentGroup.commentFormControl;
        this.modifiedTitle.next(this.title);
        this.myform.reset();
        this.activeModal.close();
    }
}