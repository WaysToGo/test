import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-navigation',
	template: `
	<div class="panel panel-default">
	<div class="panel-heading">
		<h3 class="panel-title">Gallery</h3>
	</div>
	<div class="panel-body">
		<div *ngFor="let item of itemsToDrop" [dragDirective]='item' [dragHightlight]="'highlight'" class="dragItem" >
		<app-generic-box [genericBox]='item'></app-generic-box>
		</div>
	</div>
	</div>`,
	styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {
	private itemsToDrop: Array<Object> = [
		{
			name: 'Title',
			content: 'Title'
		},
		{
			name: 'Subtitle',
			content: 'Subtitle'
		},
		{
			name: 'Hero Text',
			content: 'Hero Text'
		},
		{
			name: 'Campaign',
			content: 'Campaign'
		},
	]
	constructor() { }
	ngOnInit() {
	}
}
