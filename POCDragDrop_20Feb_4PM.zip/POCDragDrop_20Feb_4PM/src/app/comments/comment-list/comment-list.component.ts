import { Component, OnInit, Input } from '@angular/core';
import { Comment } from '../../model/Comment';
import { CommentService } from '../../services/comment.service';
 

@Component({
  selector: 'app-comment-list',
  templateUrl: './comment-list.component.html',
  styleUrls: ['./comment-list.component.css']
})
export class CommentListComponent implements OnInit {
  @Input() controlId: number;
  @Input() ChildClass: string;

  show: boolean;
  commentsList: Comment[];

  constructor(public commentService: CommentService) {
    this.commentsList = this.commentService.getCommentList();

  }

  ngOnInit(): void {
  
  }
  ngDoCheck() {
    this.commentsList = this.commentService.getCommentListById(this.controlId);
    this.show = this.commentsList == null ? false : this.commentsList.length == 0 ? false : true;
     }
}
