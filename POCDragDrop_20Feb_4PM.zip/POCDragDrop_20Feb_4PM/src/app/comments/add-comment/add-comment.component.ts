import { Component, OnInit, ViewChild, DoCheck, EventEmitter, Output, Input } from '@angular/core';
import { FormGroup, FormControl, Validators, NgForm, FormBuilder } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

import { Comment } from '../../model/Comment';
import { CommentService } from '../../services/comment.service';
import { StorageService } from '../../services/storage.service';
import { Items } from '../../model/Items';

@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.css']
})
export class AddCommentComponent implements OnInit {
  @Input() title: string;
  @Input() Id:number;
  @Output() modifiedTitle = new EventEmitter<string>();

  private items: Items[];
  myform: FormGroup;
  commentFormControl: FormControl;

  comment: Comment;
  commentList: Array<Comment>;

  ngDoCheck() {
    console.log("asdf");
    console.log(this.storageService.get("NameKey"));
  }
  constructor(public commentService: CommentService, private activeModal: NgbActiveModal,
    private storageService: StorageService) {

    this.comment = new Comment();
    this.items = new Array<Items>();
  }



  ngOnInit() {
    this.createFormControls();
    this.createForm();
  }
  createFormControls(): void {
    this.commentFormControl = new FormControl('', Validators.required);
  }
  createForm(): void {
    this.myform = new FormGroup({
      commentGroup: new FormGroup({
        commentFormControl: this.commentFormControl
      }),
    });
  }
  ClearComment(): void {
    this.storageService.deleteKey("CL");
    this.commentList = [];
    this.myform.reset();
  }
  Save(myForm: NgForm) {

    console.log("this.storageService.get(items)");
    this.items = this.storageService.get("items");
    this.comment.Comment = myForm.value.commentGroup.commentFormControl;
    this.modifiedTitle.emit(this.title);
    //this.items.find(this.title)


    // let index = this.items.filter() 
    
    // this.storageService.set("items",arrray)//
    // this.storageService.get("items")       set;;;;;

   
    this.myform.reset();
  }
  closeModal() {
    this.activeModal.close();
  }


  
}
