
export class Items {
    content: string;
}