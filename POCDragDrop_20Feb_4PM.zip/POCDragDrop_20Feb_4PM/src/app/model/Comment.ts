
export class Comment {
   Comment: string;
}
