import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DragDropDirectiveModule } from "angular4-drag-drop";
import { AppComponent } from './app.component';
import { DropAreaComponent } from './drop-area/drop-area.component';
import { NavigationComponent } from './navigation/navigation.component';
import { GenericBoxModule } from './generic-box/generic-box.module';
import { TypeCheckModule } from './type-check/type-check.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularDraggableModule } from 'angular2-draggable';
import { DefaultModal } from './models/default/default-modal.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { NgbActiveModal, NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { DraggableDomModule } from "ng2-draggable-dom";

@NgModule({
  imports: [
    BrowserModule,
    GenericBoxModule,
    DragDropDirectiveModule,
    TypeCheckModule,
    AngularDraggableModule,
    NgbModule.forRoot(),
    DraggableDomModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    AppComponent,
    DropAreaComponent,
    NavigationComponent,
    DefaultModal
  ],
  entryComponents: [
    DefaultModal
  ],
  providers:
    [
      NgbActiveModal
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }
