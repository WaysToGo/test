import { Component } from '@angular/core';
import { TypeCheckEnum } from './type-check-enum';

@Component({
  selector: 'app-type-check',
  template: `
    <div class="row">
      <h2>{{Title}}</h2>
      <div class="col-md-4">
        <app-navigation-type-check [dropItemType]='dropItemType'></app-navigation-type-check>
      </div>
      <div class="col-md-8">
        <app-drop-area-type-check (droppedItemType)="dropItemTypeCheck($event)"></app-drop-area-type-check>
      </div>
    </div>
  `
})
export class TypeCheckComponent {
  private title:String = 'Draggable Items that check to see if they are allowed to drop in drop areas';
  private dropItemType:any;
  private dropItemTypeCheck(event){
    this.dropItemType = event;
  }
}