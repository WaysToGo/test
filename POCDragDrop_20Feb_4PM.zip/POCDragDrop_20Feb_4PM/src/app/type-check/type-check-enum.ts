export class EmptyEnumClass{}
export enum TypeCheckEnum{
  Round,
  Square
}