module.exports=function countOfRepeatedChatacters(s){
    return s.length - s.replace(/(.)\1+/g, '$1').length
 };
