var assert = require('assert'); 
var countOfRepeatedChatacters=require('../app')

  describe('should return 3', function() {
    it('test7', function(){
      assert.equal(countOfRepeatedChatacters('aabbcc'), 3);
    });
    it('test1', function(){
        assert.equal(countOfRepeatedChatacters('aabbccddeeff'),6 );
      });
      it('test2', function(){
        assert.equal(countOfRepeatedChatacters('aabbccddee'), 5);
      });
      it('test3', function(){
        assert.equal(countOfRepeatedChatacters('aabbccdd'), 4);
      });
      it('test4', function(){
        assert.equal(countOfRepeatedChatacters('abbcc'), 2);
      });
      it('test5', function(){
        assert.equal(countOfRepeatedChatacters('aabc'), 1);
      });
      it('test6', function(){
        assert.equal(countOfRepeatedChatacters('abc'), 0);
      });
      it('test8', function(){
        assert.equal(countOfRepeatedChatacters('abbccab'), 2);
      });
      it('test9', function(){
        assert.equal(countOfRepeatedChatacters('abbbcc'), 3);
      });
  });


