package com.example.demo;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestWeb {
	public DesiredCapabilities caps;
	public WebDriver driver;
	public String url="http://localhost:8080/demo/home";
	@Before
	public void init() {
		caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability("takesScreenshot", true);
		caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,
				"D:\\\\projects\\\\impfile\\\\phantomjs-2.1.1-windows\\\\bin\\\\phantomjs.exe");
		// /usr/local/bin/phantomjs
		
		driver = new PhantomJSDriver(caps);

		
	}

	 
	  @Test
	  public void testOrder1() throws InterruptedException {
		     int length=3;
		     int i;
			    driver.get(url);
                 
			    List<WebElement> data = driver.findElements(By.className("row"));
			   int count= data.size();
			  
			    
			    assertEquals("Your tasks ("+count+")",driver.findElement(By.id("app-header")).getAttribute("innerText"));
			   
			    for(i=0;i<length;i++) {
			    	driver.findElement(By.id("text-area")).click();
				    driver.findElement(By.id("text-area")).clear();
				    driver.findElement(By.id("text-area")).sendKeys("test"+count);
				    driver.findElement(By.id("add-btn")).click();
				    
				    
				    count+=1;
				    Thread.sleep(1000);
				    assertEquals("Your tasks ("+count+")",driver.findElement(By.id("app-header")).getAttribute("innerText"));
					   
			    }
			    
			   		   
			driver.close();
			  }


	  
	  @Test 
	  public void testOrder2() throws InterruptedException {
		  driver.get(url);
		  List<WebElement> data = driver.findElements(By.className("row"));
		   int count= data.size();
		   count-=1;
		   driver.findElements(By.className("delete-btn")).get(0).click();
		   Thread.sleep(1000);
		   assertEquals("Your tasks ("+count+")",driver.findElement(By.id("app-header")).getAttribute("innerText"));
		    driver.close();
	  }
	  


}

