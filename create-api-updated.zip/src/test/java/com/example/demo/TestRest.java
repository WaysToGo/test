package com.example.demo;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import net.minidev.json.JSONObject;


@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestRest {

	
public String url="http://localhost:8000/demo-0.0.1-SNAPSHOT/api/tasks/";


Tasks task;
	@Test
	public void testOrder1() throws Exception {
		
		 given().get(url).then().statusCode(200);
	      
		 

	}
	
	@Test
	public void testOrder2() throws Exception {
		
		JSONObject requestParams = new JSONObject();
		requestParams.put("name", "test");
		
		given().header("Content-Type", "application/json").body(requestParams.toJSONString()).post(url);

		
		 given().get(url+"test").then().statusCode(200).body("name",is("test"));

	}
		
	
	@Test
	public void testOrder3() throws Exception {
		
	
		 given().delete(url+"test").then().statusCode(200);

	}
	@Test
	public void testOrder4() throws Exception {
		JSONObject requestParams = new JSONObject();
		requestParams.put("name", "test");
		
		given().header("Content-Type", "application/json").body(requestParams.toJSONString()).post(url).then().statusCode(201).log().all();

	}
	
	@Test
	public void testOrder5() throws Exception {
		
	
		 given().delete(url+"test").then().statusCode(200);

	}
	
	
	
}
