write a function where it should return count of number of excess characters

example
'abbbcc'   answer: 3 ->return 3
'abbccab'   answer: 2 ->return 2