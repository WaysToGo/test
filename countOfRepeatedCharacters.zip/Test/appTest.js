var assert = require('assert'); 
var countOfRepeatedCharacters=require('../app')

  describe('should return 3', function() {
    it('test7', function(){
      assert.equal(countOfRepeatedCharacters('aabbcc'), 3);
    });
    it('test1', function(){
        assert.equal(countOfRepeatedCharacters('aabbccddeeff'),6 );
      });
      it('test2', function(){
        assert.equal(countOfRepeatedCharacters('aabbccddee'), 5);
      });
      it('test3', function(){
        assert.equal(countOfRepeatedCharacters('aabbccdd'), 4);
      });
      it('test4', function(){
        assert.equal(countOfRepeatedCharacters('abbcc'), 2);
      });
      it('test5', function(){
        assert.equal(countOfRepeatedCharacters('aabc'), 1);
      });
      it('test6', function(){
        assert.equal(countOfRepeatedCharacters('abc'), 0);
      });
      it('test8', function(){
        assert.equal(countOfRepeatedCharacters('abbccab'), 2);
      });
      it('test9', function(){
        assert.equal(countOfRepeatedCharacters('abbbcc'), 3);
      });
  });


