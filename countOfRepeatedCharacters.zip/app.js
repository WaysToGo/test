module.exports=function countOfRepeatedCharacters(s){
    return s.length - s.replace(/(.)\1+/g, '$1').length
 };
