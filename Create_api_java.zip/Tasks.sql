create database restdb;
use restdb;
 create table tasks(name varchar(25),Created_date DATE,status varchar(25));