package com.example.demo;

import java.net.URI;
import java.util.Date;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("/tasks")
public class JerseyController {
	@Autowired
	TodoListRepo todoListRepo;
	
	
	
	  @GET
	    @Produces("application/json")
	    public List<Tasks> getAllTasks() {
		
	        return todoListRepo.findAll();
	    }
	  
	  @POST
	  @Consumes("application/json")
	  @Produces("application/json")
	     public Response saveAllTasks(Tasks tasks){

		  tasks.created_date=new Date();
		  todoListRepo.save(tasks);
		  return Response.created(URI.create("/" + tasks.getName())).build();
		  
	  }
	  
	  
	  @GET
	  @Path("/{name}")
	    @Produces("application/json")
	    public Tasks getTask(@PathParam("name") String name) {
		  	
	        return todoListRepo.findOne(name);
	    }
	  
	  
	  @PUT
	  @Path("/{name}")
	  @Consumes("application/json")
	  @Produces("application/json")
	  public Response saveTask(@PathParam("name") String name,Tasks task){
		  
			task.name=name;

			 task.created_date=new Date();
			 
			 todoListRepo.save(task);
			  
		  
		  return Response.noContent().build();
		  
	  }
	  
	  
	  @DELETE
	  @Path("/{name}")
	  public Response deleteTasks(@PathParam("name") String name){		  
		  todoListRepo.delete(name);
		  
		 return Response.ok().build();
		  
	  }
	  

	  
	  


}
