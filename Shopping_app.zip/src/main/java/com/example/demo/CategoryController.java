package com.example.demo;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;



@Component
@Path("category")
public class CategoryController {
	
	@Autowired
	CategoryRepo categoryRepo;
		
	  @GET
	    @Produces("application/json")
	    public List<CategoryModel> getAlldetails() {		
	        return categoryRepo.findAll();
	    }
	  
	
	  
	  @GET
	  @Path("/{id}")
	    @Produces("application/json")
	    public CategoryModel getDetails(@PathParam("id") Long id) {	 	
	        return categoryRepo.findOne(id);
	        }
	  
	
	  

	  
	  


}
