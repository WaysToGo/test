package com.example.demo;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CartTestWeb {
	public DesiredCapabilities caps;
	public WebDriver driver;
	public String url="http://localhost:8000/Shopping-cart-app/";
	@Before
	public void init() {
		caps = new DesiredCapabilities();
		caps.setJavascriptEnabled(true);
		caps.setCapability("takesScreenshot", true);
    final ChromeOptions chromeOptions = new ChromeOptions();
    // chromeOptions.setBinary("/opt/chromedriver");
    chromeOptions.addArguments("--headless");
    chromeOptions.addArguments("--disable-gpu");
    chromeOptions.addArguments("--no-sandbox");
    caps.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
    System.setProperty("webdriver.chrome.driver", "/opt/chromedriver");
    
//    System.setProperty("webdriver.chrome.driver", "D:\\projects\\impfile\\chromedriver.exe");
    driver = new ChromeDriver(caps);


		
	}


	  
	  @Test 
	  public void testOrder1() throws InterruptedException {
		 
		  try{driver.get(url);
		  driver.findElement(By.id("count")).click();
		  Thread.sleep(2000);
		  List<WebElement> data = driver.findElements(By.className("row"));
		   int count= data.size();
		  	
		   count-=1;
		   Thread.sleep(2000);
		   driver.findElements(By.className("delete-btn")).get(0).click();
		   Thread.sleep(2000);
		   List<WebElement> afterdata = driver.findElements(By.className("row"));
		   int aftercount= afterdata.size();
		   Thread.sleep(2000);
		   //System.out.println(driver.getPageSource());
		   assertEquals(count,aftercount);
		  }
		  finally {
		    driver.close();
		  }
	  }
	  


}

