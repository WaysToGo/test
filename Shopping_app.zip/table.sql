create database restdb;
use restdb;



-- use this after build process is complete 


insert into product values(101,"mouse",9,"sample","sample","testMouse","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",1000,10); 


insert into product values(102,"keyboard",9,"sample","sample","testKeyboard","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",100,10);


insert into product values(103,"mobile",9,"sample","sample","testMobile","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",10000,10);


insert into product values(104,"mouse",9,"sample","sample","testMouse","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",1000,10); 


insert into product values(105,"keyboard",9,"sample","sample","testKeyboard","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",100,10);


insert into product values(106,"mobile",9,"sample","sample","testMobile","https://images.unsplash.com/photo-1503942142281-94af0aded523?ixlib=rb-0.3.5&q=85&fm=jpg&crop=entropy&cs=srgb&ixid=eyJhcHBfaWQiOjE0NTg5fQ&s=343652fb4c1f9b09bffc98b10a0058f3",10000,10);

