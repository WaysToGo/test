import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  _baseURL="http://localhost:3000/products";
  constructor(private http: Http) {
  }

  filter='mouse';
  sample(a) {
    this.filter=a;
    console.log(this.filter);
 
    
  }
  
  details: any = [];
  getAllDetails = function () {
    this.http.get(this._baseURL).subscribe((res: Response) => {
      let data = res.json();
      this.details = data; 
    })
  };
   filterDetails = function (value) {
    this.http.get(this._baseURL).subscribe((res: Response) => {
      let data = res.json();
      this.details =data.filter(a=>a.category==value);
    
    })
  };
  ngOnInit() {
   
  this.getAllDetails();
  }

}
